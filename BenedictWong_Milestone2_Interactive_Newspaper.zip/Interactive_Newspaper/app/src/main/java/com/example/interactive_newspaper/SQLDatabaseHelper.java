package com.example.interactive_newspaper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
// Code learned from https://demonuts.com/sqlite-android/

public class SQLDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "newspaperDatabase";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "newspaperTable";
    private static final String UID = "_id";
    private static final String NAME = "Name";
    private static final String TYPE = "Type";

    private static final String CREATE_TABLE = "CREATE TABLE "+ TABLE_NAME + "(" + UID + " INTEGER PRIMARY KEY AUTOINCREMENT,"+ NAME + " TEXT )";


    public SQLDatabaseHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS '" + TABLE_NAME + "'");
        onCreate(db);
    }

    public long addDatabaseDetail(String data){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues value = new ContentValues();
        value.put(NAME, data);
        long insert = db.insert(TABLE_NAME, null, value);

        return insert;
    }
    public void delDatabaseDetal(int index){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM "+TABLE_NAME+ " WHERE " + UID + " = "+index);

    }

    public ArrayList<String> getAllData(){
        ArrayList<String> dataArrayList = new ArrayList<String>();
        String name = "";
        String selectQuery = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);
        if(c.moveToFirst()){
            do {
                name = c.getString(c.getColumnIndex(NAME));
                dataArrayList.add(name);
            }
            while (c.moveToNext());
            Log.d("ARRAY", dataArrayList.toString());

        }
        return dataArrayList;
    }

}
