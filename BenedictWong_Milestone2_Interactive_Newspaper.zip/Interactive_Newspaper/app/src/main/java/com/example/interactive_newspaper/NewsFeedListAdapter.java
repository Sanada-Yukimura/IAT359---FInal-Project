package com.example.interactive_newspaper;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import static android.content.Context.SENSOR_SERVICE;

public class NewsFeedListAdapter extends RecyclerView.Adapter<NewsFeedListAdapter.FeedModelViewHolder> implements SensorEventListener  {
    Context context;
    private List<NewsFeedModel> myNewsFeedModels;
    private Sports sports = new Sports();
    private WorldNews worldNews = new WorldNews();
    private LocalNews localNews = new LocalNews();

    public NewsFeedListAdapter(List<NewsFeedModel> newsFeedModels) {
        myNewsFeedModels = newsFeedModels;

    }





    @Override
    public NewsFeedListAdapter.FeedModelViewHolder onCreateViewHolder(ViewGroup parent, int type) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.news_item, parent, false);
        FeedModelViewHolder holder = new FeedModelViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(FeedModelViewHolder holder, int position)

    {

        final NewsFeedModel newsFeedModel = myNewsFeedModels.get(position);
        ((TextView)holder.newsFeedView.findViewById(R.id.titleText)).setText(newsFeedModel.title);
        ((TextView)holder.newsFeedView.findViewById(R.id.titleText)).setTextColor(ContextCompat.getColor(context, R.color.darkSecondaryFont));
        ((TextView)holder.newsFeedView.findViewById(R.id.descriptionText)).setText(newsFeedModel.descrip);
        ((TextView)holder.newsFeedView.findViewById(R.id.descriptionText)).setTextColor(ContextCompat.getColor(context, R.color.darkSecondaryFont));
        ((TextView)holder.newsFeedView.findViewById(R.id.linkText)).setText(newsFeedModel.url);

    }

    @Override
    public int getItemCount() {
        return myNewsFeedModels.size();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    public class FeedModelViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private View newsFeedView;


        public FeedModelViewHolder(View v) {
            super(v);
            newsFeedView = v;
            v.setOnClickListener(this);
            context = v.getContext();
        }
        // Clicking on any recyclerView card will open up the browser for the full news article.
        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            NewsFeedModel thisNews = myNewsFeedModels.get(position);
            String url = thisNews.url;
            String website = url.substring(url.indexOf("w"), url.length());
            website = "http://"+website;
            Uri webpage = Uri.parse(website);
            Intent intent = new Intent(Intent.ACTION_VIEW, webpage);

            context.startActivity(intent);
        }
    }

}
